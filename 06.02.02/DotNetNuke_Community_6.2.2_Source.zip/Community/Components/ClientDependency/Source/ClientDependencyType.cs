﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ClientDependency.Core
{
	/// <summary>
	/// The type of client file
	/// </summary>
	public enum ClientDependencyType
	{
		Javascript, Css
	}
}
