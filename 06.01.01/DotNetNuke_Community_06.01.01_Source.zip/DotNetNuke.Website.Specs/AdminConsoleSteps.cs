﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using DotNetNuke.Tests.UI.WatiN.Common;
using DotNetNuke.Tests.UI.WatiN.Common.WatiNObjects;

using Store.TestingUtilities;

using TechTalk.SpecFlow;
using WatiN.Core;

namespace DotNetNuke.Website.Specs
{
    [Binding]
    public class AdminConsoleSteps : DnnUnitTest
    {
        //protected IE IeInstance;
        private string _siteUrl = ConfigurationManager.AppSettings["SiteURL"];
        private WatiNBase _homePage;
        private AdminConsole _adminConsole;

        public AdminConsoleSteps()
            : base(0)
        {
        }

        [Given(@"I am ./(*) in")]
        public void GivenIAmLoggedIn()
        {
            _homePage = new WatiNBase(new IE(), _siteUrl, "test");
            var loginPage = new LoginPage(_homePage);
            loginPage.LoginUser(TestUsers.AdminUpdatedPassword.UserName, TestUsers.AdminUpdatedPassword.Password);
        }

        [Given(@"I am a site administrator")]
        public void GivenIAmASiteAdministrator()
        {
            //ScenarioContext.Current.Pending();
        }

        [When(@"I click the Admin link")]
        public void WhenIClickTheAdminLink()
        {
            System.Threading.Thread.Sleep(1000);
            _homePage.AdminConsoleLink.ClickNoWait();
        }

        [Then(@"I should see these Icons")]
        public void ThenIShouldSeeTheseIcons(TechTalk.SpecFlow.Table table)
        {
            System.Threading.Thread.Sleep(1000);
            _adminConsole = new AdminConsole(_homePage);

            foreach (var row in table.Rows)
            {
                NUnit.Framework.Assert.IsTrue(_adminConsole.ContentPane.Image(Find.ByAlt(row["Icons"])).Exists);
            }
        }
    }
}
