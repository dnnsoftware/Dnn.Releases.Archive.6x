﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using DotNetNuke.Common.Utilities;
using DotNetNuke.Entities.Portals;
using DotNetNuke.Entities.Users;
using DotNetNuke.Tests.UI.WatiN.Common;
using DotNetNuke.Tests.UI.WatiN.Common.WatiNObjects;

using Store.TestingUtilities;

using TechTalk.SpecFlow;
using WatiN.Core;

namespace DotNetNuke.Website.Specs
{
    [Binding]
    public class AdminInsecureLoginSteps : DnnUnitTest
    {
        //protected IE IeInstance;
        private string _siteUrl = "localhost/DotNetNuke_Enterprise";
        private WatiNBase _homePage;
        private LoginPage _loginPage;

        public AdminInsecureLoginSteps()
            : base(0)
        {
        }

        [BeforeScenario("MustBeDefaultCredentials")]
        public void ScenarioSetup()
        {
            //Here we make sure that the Admin credentials are default and set to ForceUpdate.
            var userInfo = UserController.GetUserByName(0, "admin");
            //var success = UserController.ChangePassword(userInfo, Null.NullString, TestUsers.Admin.Password);
            //userInfo.Membership.UpdatePassword = true;

            var portalSettings = PortalController.GetCurrentPortalSettings();
        } 

        [Given(@"I have entered the default Admin Username and the default password")]
        public void GivenIHaveEnteredTheDefaultAdminUsernameAndTheDefaultPassword()
        {
            _homePage = new WatiNBase(new IE(), _siteUrl, "test");
            _loginPage = new LoginPage(_homePage);
            _loginPage.EnterUserLogin(TestUsers.Admin.UserName, TestUsers.Admin.Password);
        }

        [When(@"I press Login")]
        public void WhenIPressLogin()
        {
            _loginPage.LoginButton.ClickNoWait();
        }

        [Then(@"I should be forced to enter a new password to proceed")]
        public void ThenIShouldBeForcedToEnterANewPasswordToProceed()
        {
            System.Threading.Thread.Sleep(1500);
            NUnit.Framework.Assert.IsTrue(_loginPage.OldPassword.Exists);
        }

        [Given(@"I have pressed Login")]
        public void GivenIHavePressedLogin()
        {
            _loginPage.LoginButton.ClickNoWait();
        }

        [When(@"I enter and confirm my new password")]
        public void WhenIEnterAndConfirmMyNewPassword()
        {
            _loginPage.UpdatePassword(TestUsers.Admin.Password, TestUsers.AdminUpdatedPassword.Password, TestUsers.AdminUpdatedPassword.Password);
        }

        [Then(@"I should be logged in")]
        public void ThenIShouldBeLoggedIn()
        {
            System.Threading.Thread.Sleep(1500);
            NUnit.Framework.Assert.IsTrue(_loginPage.LoginLink.Text.ToLower() == "logout");
        }

    }
}
